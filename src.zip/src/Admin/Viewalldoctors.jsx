import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import config from '../config';

export default function ViewallDoctors() {
  const [doctors, setDoctors] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get(`${config.url}/admin/alldoctors`).then(res => {
        setDoctors(res.data);
      }).catch(err => {
        toast.error('Failed to fetch doctors.');
        setError('Unable to load doctors.');
        console.error(err);
      });
  }, []);

  return (
    <div className="container mt-4">
      <ToastContainer position="top-center" autoClose={3000} />
      <h3 className="text-center mb-4">All Registered Doctors</h3>

      {doctors.length > 0 ? (
        <table className="table table-bordered table-hover">
          <thead className="thead-dark">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Username</th>
              <th>Specialization</th>
              <th>Experience</th>
              <th>Mobile</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {doctors.map((doc, index) => (
              <tr key={index}>
                <td>{doc.name}</td>
                <td>{doc.email}</td>
                <td>{doc.username}</td>
                <td>{doc.specialization}</td>
                <td>{doc.experience} yrs</td>
                <td>{doc.mobile}</td>
                <td>{doc.location}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-center">{error || 'No doctors found.'}</p>
      )}
    </div>
  );
}
