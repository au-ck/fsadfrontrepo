import React from 'react'

export default function PatientHome() {
  return (
    <div>
      
    </div>
  )
}
