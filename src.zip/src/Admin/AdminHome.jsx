import React from 'react'

export default function AdminHome() {
  return (
    <div>
      
    </div>
  )
}
