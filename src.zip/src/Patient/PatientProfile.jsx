import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent, Typography, Button, Avatar } from '@mui/material';
import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

export default function PatientProfile() {
  const [patient, setPatient] = useState(null);
  const patientId = sessionStorage.getItem('patient_id');

  const handleSubmit = async (e) => {
  e.preventDefault();
  try {
    const response = await axios.post(`${config.url}/patient/checkpatientlogin`, formData);
    if (response.status === 200) {
      sessionStorage.setItem('patient_id', response.data.id);  
      setIsPatientLoggedIn(true);
      navigate("/patienthome");
    }
  } catch (error) {
    console.error(error);
    setError('Login failed. Please check your credentials.');
  }
};

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
      <ToastContainer position="top-center" autoClose={3000} />
      {patient ? (
        <Card sx={{ maxWidth: 500, width: '100%' }} className="shadow">
          <CardContent>
            <div className="text-center mb-3">
              <Avatar sx={{ width: 80, height: 80, margin: '0 auto' }} />
              <Typography variant="h5" className="mt-2">{patient.name}</Typography>
              <Typography variant="subtitle1" color="textSecondary">{patient.email}</Typography>
            </div>

            <Typography><strong>Gender:</strong> {patient.gender}</Typography>
            <Typography><strong>Date of Birth:</strong> {patient.dob}</Typography>
            <Typography><strong>Mobile:</strong> {patient.mobile}</Typography>
            <Typography><strong>Location:</strong> {patient.location}</Typography>

            <div className="text-center mt-4">
              <Button variant="outlined" color="primary">Edit Profile</Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <p>Loading profile...</p>
      )}
    </div>
  );
}
