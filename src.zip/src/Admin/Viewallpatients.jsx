import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import config from '../config';
export default function Viewallpatients() {
  const [patients, setPatients] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get(`${config.url}/admin/allpatients`)
      .then(res => {
        setPatients(res.data);
      })
      .catch(err => {
        toast.error('Failed to fetch patients.');
        setError('Unable to load patients.');
        console.error(err);
      });
  }, []);

  return (
    <div className="container mt-4">
      <ToastContainer position="top-center" autoClose={3000} />
      <h3 className="text-center mb-4">All Registered Patients</h3>

      {patients.length > 0 ? (
        <table className="table table-bordered table-hover">
          <thead className="thead-dark">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Username</th>
              <th>Gender</th>
              <th>Date of Birth</th>
              <th>Mobile</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((patient, index) => (
              <tr key={index}>
                <td>{patient.name}</td>
                <td>{patient.email}</td>
                <td>{patient.username}</td>
                <td>{patient.gender}</td>
                <td>{patient.dob}</td>
                <td>{patient.mobile}</td>
                <td>{patient.location}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-center">{error || 'No patients found.'}</p>
      )}
    </div>
  );
}
