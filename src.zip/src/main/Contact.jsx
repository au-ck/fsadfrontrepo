import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    message: '',
    email: '',
    mobileno: '',
    location: ''
  });

  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simulate success without backend
    if (formData.name && formData.email && formData.message) {
      setMessage('Form submitted successfully!');
      setError('');
      setFormData({
        name: '',
        subject: '',
        message: '',
        email: '',
        mobileno: '',
        location: ''
      });
    } else {
      setError('Please fill in all required fields.');
      setMessage('');
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '20px' }}>
      <div style={{
        background: '#f9f9f9',
        padding: '30px',
        borderRadius: '15px',
        boxShadow: '0 0 15px rgba(0,0,0,0.1)',
        width: '400px'
      }}>
        <h3 style={{ textAlign: 'center', textDecoration: 'underline' }}>Contact Us</h3>
        {message && (
          <p style={{ textAlign: 'center', color: 'green', fontWeight: 'bolder' }}>{message}</p>
        )}
        {error && (
          <p style={{ textAlign: 'center', color: 'red', fontWeight: 'bolder' }}>{error}</p>
        )}
        <form onSubmit={handleSubmit}>
          {['name', 'subject', 'message', 'email', 'mobileno', 'location'].map((field) => (
            <div key={field} style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                {field.charAt(0).toUpperCase() + field.slice(1).replace('no', ' No')}
              </label>
              <input
                type={field === 'email' ? 'email' : field === 'mobileno' ? 'number' : 'text'}
                id={field}
                value={formData[field]}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '5px',
                  border: '1px solid #ccc'
                }}
              />
            </div>
          ))}
          <button type="submit" style={{
            width: '100%',
            padding: '10px',
            background: 'linear-gradient(to right, #000000, #434343)',
            color: 'white',
            fontWeight: 'bold',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}>
            Submit
          </button>
        </form>
      </div>
    </div>
  );
}