import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent, Typography, Button, Avatar } from '@mui/material';
import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
import config from '../config';
export default function DoctorProfile() {
  const [doctor, setDoctor] = useState(null);
  const doctorId = sessionStorage.getItem('doctor_id');

  useEffect(() => {
    if (doctorId) {
      axios.get(`${config.url}/doctor/profile/${doctorId}`)
        .then(res => setDoctor(res.data))
        .catch(err => {
          toast.error('Failed to load profile.');
          console.error(err);
        });
    } else {
      toast.error('Please login to view profile.');
    }
  }, [doctorId]);

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
      <ToastContainer position="top-center" autoClose={3000} />
      {doctor ? (
        <Card sx={{ maxWidth: 500, width: '100%' }} className="shadow">
          <CardContent>
            <div className="text-center mb-3">
              <Avatar sx={{ width: 80, height: 80, margin: '0 auto' }} />
              <Typography variant="h5" className="mt-2">{doctor.name}</Typography>
              <Typography variant="subtitle1" color="textSecondary">{doctor.email}</Typography>
            </div>

            <Typography><strong>Specialization:</strong> {doctor.specialization}</Typography>
            <Typography><strong>Experience:</strong> {doctor.experience} years</Typography>
            <Typography><strong>Mobile:</strong> {doctor.mobile}</Typography>
            <Typography><strong>Location:</strong> {doctor.location}</Typography>

            <div className="text-center mt-4">
              <Button variant="outlined" color="primary">Edit Profile</Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <p>Loading profile...</p>
      )}
    </div>
  );
}
