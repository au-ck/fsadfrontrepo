import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config';

export default function Appointment() {
  const [appointments, setAppointments] = useState([]);
  const [newAppointment, setNewAppointment] = useState({
    doctorName: '',
    date: '',
    time: ''
  });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const patientId = sessionStorage.getItem('patient_id'); 

  useEffect(() => {
    if (patientId) {
      axios.get(`${config.url}/patient/appointments/${patientId}`).then(res => {
          setAppointments(res.data);
        })
        .catch(err => {
          setError('Could not fetch appointments.');
          console.error(err);
        });
    }
  }, [patientId]);

  const handleChange = (e) => {
    setNewAppointment({ ...newAppointment, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${config.url}/patient/appointments`, {
        ...newAppointment,
        patientId: patientId
      });

      if (res.status === 200 ) {
        setMessage('Appointment request sent!');
        setNewAppointment({ doctorName: '', date: '', time: '' });
        setAppointments(prev => [...prev, res.data]);
      }
    } catch (err) {
      setError('Failed to request appointment.');
      console.error(err);
    }
  };

  return (
    <div className="container mt-4">
      <h3 className="text-center mb-4">Your Appointments</h3>
      {appointments.length > 0 ? (
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Doctor</th>
              <th>Date</th>
              <th>Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((app, index) => (
              <tr key={index}>
                <td>{app.doctorName}</td>
                <td>{app.date}</td>
                <td>{app.time}</td>
                <td>{app.status || 'Pending'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-center">No appointments found.</p>
      )}
      <h4 className="mt-5">Request a New Appointment</h4>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Doctor Name</label>
          <input type="text" name="doctorName"className="form-control" value={newAppointment.doctorName}onChange={handleChange}required/>
        </div>
        <div className="form-group">
          <label>Date</label>
          <input type="date" name="date" className="form-control" value={newAppointment.date}onChange={handleChange}required/>
        </div>
        <div className="form-group">
          <label>Time</label>
          <select name="time" className="form-control" value={newAppointment.time} onChange={handleChange} required >
          <option value="">Select Time</option>
          <option value="8:00 AM">8:00 AM</option>
          <option value="9:00 AM">9:00 AM</option>
          <option value="10:00 AM">10:00 AM</option>
          <option value="11:00 AM">11:00 AM</option>
          <option value="12:00 PM">12:00 PM</option>
          <option value="1:00 PM">1:00 PM</option>
          <option value="2:00 PM">2:00 PM</option>
          <option value="3:00 PM">3:00 PM</option>
          <option value="4:00 PM">4:00 PM</option>
          <option value="5:00 PM">5:00 PM</option>
         <option value="6:00 PM">6:00 PM</option>
       </select>
        </div>
        <button type="submit" className="btn btn-primary mt-3">Request Appointment</button>
      </form>

      {message && <p className="text-success mt-3">{message}</p>}
      {error && <p className="text-danger mt-3">{error}</p>}
    </div>
  );
}
