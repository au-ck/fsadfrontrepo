const config = 
{
    "url":"http://localhost:5"
}

export default config